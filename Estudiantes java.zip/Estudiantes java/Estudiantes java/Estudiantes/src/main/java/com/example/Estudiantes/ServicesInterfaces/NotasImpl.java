package com.example.Estudiantes.ServicesInterfaces;

public interface NotasImpl {
}
