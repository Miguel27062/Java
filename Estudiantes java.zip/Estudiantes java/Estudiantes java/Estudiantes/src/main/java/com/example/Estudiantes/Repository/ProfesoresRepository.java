package com.example.Estudiantes.Repository;

import com.example.Estudiantes.Entity.Profesores;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfesoresRepository extends JpaRepository<Profesores, Long> {

}
