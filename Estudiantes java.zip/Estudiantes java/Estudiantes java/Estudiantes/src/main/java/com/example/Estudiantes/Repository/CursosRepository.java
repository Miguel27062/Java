package com.example.Estudiantes.Repository;

import com.example.Estudiantes.Entity.Cursos;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CursosRepository extends JpaRepository<Cursos, Long> {

}
