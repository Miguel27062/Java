package com.example.Estudiantes.Repository;

import com.example.Estudiantes.Entity.Salones;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalonesRepository extends JpaRepository<Salones, Long> {

}
