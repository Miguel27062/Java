package com.example.Estudiantes.Repository;

import com.example.Estudiantes.Entity.Notas;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotasRepository extends JpaRepository<Notas, Long> {

}
