package com.example.Estudiantes.Repository;

import com.example.Estudiantes.Entity.Horarios;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HorariosRepository extends JpaRepository<Horarios, Long> {

}
